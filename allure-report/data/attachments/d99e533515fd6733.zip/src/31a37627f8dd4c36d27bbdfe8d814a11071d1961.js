const { test, expect } = require('@playwright/test');
const { LoginPage } = require('../pages/LoginPage');

test('OrangeHRM Capstone - Login Test with POM and .env', async ({ page }) => {
  const loginPage = new LoginPage(page);
  await loginPage.goto();
  
  const user = process.env.USERNAME || 'Admin';
  const pass = process.env.PASSWORD || 'admin123';
  
  await loginPage.login(user, pass);
  await page.waitForTimeout(3000);
  await expect(page).toHaveURL(/.*dashboard/);
  await expect(page.getByText('Dashboard').first()).toBeVisible();
});

test('Invalid Login Test - Should show error', async ({ page }) => {
  const loginPage = new LoginPage(page);
  await loginPage.goto();
  await loginPage.login('WrongUser', 'WrongPass123');
  await expect(page.getByText('Invalid credentials')).toBeVisible();
});