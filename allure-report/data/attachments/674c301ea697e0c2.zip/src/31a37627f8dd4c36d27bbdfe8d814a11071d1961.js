const { test, expect } = require('@playwright/test');
const { LoginPage } = require('../pages/LoginPage');

test('OrangeHRM Capstone - Login Test with POM and .env', async ({ page }) => {
  const loginPage = new LoginPage(page);

  // Step 1: Go to Login Page (BaseURL will come from .env)
  await loginPage.goto();

  // Step 2: Login using .env credentials
  await loginPage.login(process.env.USERNAME, process.env.PASSWORD);

  // Step 3: Verify Dashboard
  await expect(page).toHaveURL(/dashboard/);
  await expect(page.getByText('Dashboard').first()).toBeVisible();
  
  console.log('Login Successfully with POM!');
});